package com.gamebooster.pro;

import android.app.AlertDialog;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView tvRam, tvBattery, tvSelectedApp;
    private Switch swDnd, swKeepScreen, swLockOrientation, swSustainedPerf;
    private SeekBar sbOptimalValue;
    private TextView tvOptimalValue;
    private DrawerLayout drawerLayout;
    private boolean gameModeOn = false;
    private String selectedPackage = null;
    private String selectedLabel = null;
    private final Handler statsHandler = new Handler(Looper.getMainLooper());

    private final Runnable statsRunnable = new Runnable() {
        @Override public void run() {
            updateRamInfo();
            updateBatteryInfo();
            statsHandler.postDelayed(this, 2000);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerLayout = findViewById(R.id.drawerLayout);
        tvRam = findViewById(R.id.tvRam);
        tvBattery = findViewById(R.id.tvBattery);
        tvSelectedApp = findViewById(R.id.tvSelectedApp);
        swDnd = findViewById(R.id.swDnd);
        swKeepScreen = findViewById(R.id.swKeepScreen);
        swLockOrientation = findViewById(R.id.swLockOrientation);
        swSustainedPerf = findViewById(R.id.swSustainedPerf);
        sbOptimalValue = findViewById(R.id.sbOptimalValue);
        tvOptimalValue = findViewById(R.id.tvOptimalValue);

        loadOptimalValue();
        sbOptimalValue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateOptimalValueLabel(progress);
                if (fromUser) saveOptimalValue(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        findViewById(R.id.btnMenu).setOnClickListener(v -> drawerLayout.openDrawer(Gravity.LEFT));
        findViewById(R.id.btnAddFile).setOnClickListener(v -> showFileActions());
        findViewById(R.id.btnChooseApp).setOnClickListener(v -> chooseGame());
        findViewById(R.id.btnLaunchApp).setOnClickListener(v -> boostAndLaunch());
        findViewById(R.id.btnClearCache).setOnClickListener(v -> clearAppCache());

        findViewById(R.id.navApps).setOnClickListener(v -> {
            drawerLayout.closeDrawer(Gravity.LEFT);
            chooseGame();
        });
        findViewById(R.id.navFiles).setOnClickListener(v -> {
            drawerLayout.closeDrawer(Gravity.LEFT);
            showInternalFiles();
        });
        findViewById(R.id.navSettings).setOnClickListener(v -> {
            drawerLayout.closeDrawer(Gravity.LEFT);
            Toast.makeText(this, "Thiết lập ở màn hình chính đã được lưu theo phiên.", Toast.LENGTH_SHORT).show();
        });

        loadSelectedApp();
    }

    @Override protected void onResume() {
        super.onResume();
        statsHandler.post(statsRunnable);
    }

    @Override protected void onPause() {
        super.onPause();
        statsHandler.removeCallbacks(statsRunnable);
    }

    private void loadOptimalValue() {
        int value = getSharedPreferences("booster", MODE_PRIVATE)
                .getInt("optimal_reference_value", 50);
        sbOptimalValue.setProgress(value);
        updateOptimalValueLabel(value);
    }

    private void saveOptimalValue(int value) {
        getSharedPreferences("booster", MODE_PRIVATE).edit()
                .putInt("optimal_reference_value", value)
                .apply();
    }

    private void updateOptimalValueLabel(int value) {
        if (tvOptimalValue != null) {
            tvOptimalValue.setText("Giá trị tối ưu: " + value + "%");
        }
    }

    private void loadSelectedApp() {
        android.content.SharedPreferences sp = getSharedPreferences("booster", MODE_PRIVATE);
        selectedPackage = sp.getString("package", null);
        selectedLabel = sp.getString("label", null);
        if (selectedPackage != null && selectedLabel != null) tvSelectedApp.setText(selectedLabel);
    }

    private void chooseGame() {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN, null);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> infos = pm.queryIntentActivities(main, 0);
        Collections.sort(infos, Comparator.comparing(a -> a.loadLabel(pm).toString().toLowerCase()));

        final ArrayList<ResolveInfo> apps = new ArrayList<>(infos);
        String[] names = new String[apps.size()];
        for (int i = 0; i < apps.size(); i++) names[i] = apps.get(i).loadLabel(pm).toString();

        new AlertDialog.Builder(this)
                .setTitle("Chọn ứng dụng / game")
                .setItems(names, (d, which) -> {
                    ResolveInfo ri = apps.get(which);
                    selectedPackage = ri.activityInfo.packageName;
                    selectedLabel = ri.loadLabel(pm).toString();
                    tvSelectedApp.setText(selectedLabel);
                    getSharedPreferences("booster", MODE_PRIVATE).edit()
                            .putString("package", selectedPackage)
                            .putString("label", selectedLabel).apply();
                    Toast.makeText(this, "Đã chọn " + selectedLabel, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Hủy", null).show();
    }

    private void boostAndLaunch() {
        if (selectedPackage == null) {
            chooseGame();
            return;
        }
        gameModeOn = true;
        applyKeepScreenOn(swKeepScreen.isChecked());
        applyOrientationLock(swLockOrientation.isChecked());
        applySustainedPerformance(swSustainedPerf.isChecked());
        if (swDnd.isChecked()) applyDnd(true);

        Intent launch = getPackageManager().getLaunchIntentForPackage(selectedPackage);
        if (launch == null) {
            Toast.makeText(this, "Không thể mở ứng dụng đã chọn.", Toast.LENGTH_SHORT).show();
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Toast.makeText(this, "Boost đã thiết lập. Đang mở " + selectedLabel, Toast.LENGTH_SHORT).show();
        startActivity(launch);
    }

    private void applyKeepScreenOn(boolean on) {
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void applyOrientationLock(boolean on) {
        if (on) setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        else setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    private void applySustainedPerformance(boolean on) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) getWindow().setSustainedPerformanceMode(on);
    }

    private void applyDnd(boolean on) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (!nm.isNotificationPolicyAccessGranted()) {
            if (on) {
                Toast.makeText(this, "Cần cấp quyền Không làm phiền trong Cài đặt.", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            }
            return;
        }
        nm.setInterruptionFilter(on ? NotificationManager.INTERRUPTION_FILTER_PRIORITY :
                NotificationManager.INTERRUPTION_FILTER_ALL);
    }

    private void updateRamInfo() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        if (am == null) return;
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long avail = mi.availMem / (1024 * 1024);
        long total = mi.totalMem / (1024 * 1024);
        int used = total > 0 ? (int)(100 - (avail * 100 / total)) : 0;
        tvRam.setText(String.format("RAM khả dụng: %d MB / %d MB • đang dùng %d%%", avail, total, used));
    }

    private void updateBatteryInfo() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent battery = registerReceiver(null, filter);
        if (battery == null) return;
        int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        int pct = scale > 0 ? (int)(level * 100f / scale) : -1;
        float temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
        boolean charging = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_CHARGING;
        tvBattery.setText(String.format("Pin: %d%% • Nhiệt độ: %.1f°C%s", pct, temp, charging ? " • Đang sạc" : ""));
    }

    private void clearAppCache() {
        boolean success = deleteDirContents(getCacheDir());
        System.gc();
        Toast.makeText(this, success ? "Đã dọn cache Gaming Booster." : "Cache đã trống.", Toast.LENGTH_SHORT).show();
    }

    private boolean deleteDirContents(File dir) {
        if (dir == null || !dir.isDirectory()) return false;
        String[] children = dir.list();
        if (children == null) return false;
        boolean any = false;
        for (String child : children) {
            File f = new File(dir, child);
            if (f.isDirectory()) deleteDirContents(f);
            if (f.delete()) any = true;
        }
        return any;
    }

    private void showFileActions() {
        final String[] actions = {"📂 Chọn file từ máy", "📝 Tạo file mới trong app"};
        new AlertDialog.Builder(this).setTitle("Thêm file").setItems(actions, (d, which) -> {
            if (which == 0) openFilePicker();
            else openNewFileEditor();
        }).show();
    }

    private void openFilePicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, 501);
    }

    private void openNewFileEditor() {
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra("new_file", true);
        startActivity(i);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 501 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                String name = "import_" + System.currentTimeMillis() + ".txt";
                File dest = new File(getFilesDir(), name);
                java.io.InputStream in = getContentResolver().openInputStream(data.getData());
                java.io.FileOutputStream out = new java.io.FileOutputStream(dest);
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close(); out.close();
                Intent edit = new Intent(this, EditorActivity.class);
                edit.putExtra("file_path", dest.getAbsolutePath());
                startActivity(edit);
            } catch (Exception e) {
                Toast.makeText(this, "Không đọc được file: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void showInternalFiles() {
        File[] files = getFilesDir().listFiles();
        if (files == null || files.length == 0) {
            new AlertDialog.Builder(this).setTitle("Trình quản lý file")
                    .setMessage("Chưa có file nào trong app.\nBấm dấu + để chọn file hoặc tạo file mới.")
                    .setPositiveButton("Đóng", null).show();
            return;
        }
        ArrayList<File> list = new ArrayList<>();
        for (File f : files) if (f.isFile()) list.add(f);
        String[] names = new String[list.size()];
        for (int i = 0; i < list.size(); i++) names[i] = list.get(i).getName();

        new AlertDialog.Builder(this).setTitle("File trong Gaming Booster")
                .setItems(names, (d, which) -> {
                    Intent edit = new Intent(this, EditorActivity.class);
                    edit.putExtra("file_path", list.get(which).getAbsolutePath());
                    startActivity(edit);
                })
                .setNegativeButton("Đóng", null).show();
    }
}
