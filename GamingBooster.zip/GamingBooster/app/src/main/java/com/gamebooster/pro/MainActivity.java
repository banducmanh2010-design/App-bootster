package com.gamebooster.pro;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private TextView tvRam;
    private TextView tvBattery;
    private Switch swDnd;
    private Switch swKeepScreen;
    private Switch swLockOrientation;
    private Switch swSustainedPerf;
    private Button btnGameMode;
    private Button btnClearCache;
    private Button btnVivoAutostart;

    private boolean gameModeOn = false;

    private final Handler statsHandler = new Handler(Looper.getMainLooper());
    private final Runnable statsRunnable = new Runnable() {
        @Override
        public void run() {
            updateRamInfo();
            updateBatteryInfo();
            statsHandler.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvRam = findViewById(R.id.tvRam);
        tvBattery = findViewById(R.id.tvBattery);
        swDnd = findViewById(R.id.swDnd);
        swKeepScreen = findViewById(R.id.swKeepScreen);
        swLockOrientation = findViewById(R.id.swLockOrientation);
        swSustainedPerf = findViewById(R.id.swSustainedPerf);
        btnGameMode = findViewById(R.id.btnGameMode);
        btnClearCache = findViewById(R.id.btnClearCache);
        btnVivoAutostart = findViewById(R.id.btnVivoAutostart);

        btnGameMode.setOnClickListener(v -> toggleGameMode());
        btnClearCache.setOnClickListener(v -> clearAppCache());
        btnVivoAutostart.setOnClickListener(v -> openVivoAutostartSettings());

        // Máy Vivo (Funtouch OS) rất hay tự kill app chạy nền. Chỉ hiện nút
        // này khi phát hiện đúng là thiết bị Vivo, để hướng dẫn người dùng
        // vào đúng màn hình cấp quyền "Tự khởi động" của hãng.
        if ("vivo".equalsIgnoreCase(Build.MANUFACTURER)) {
            btnVivoAutostart.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        statsHandler.post(statsRunnable);
    }

    @Override
    protected void onPause() {
        super.onPause();
        statsHandler.removeCallbacks(statsRunnable);
    }

    // ------------------------------------------------------------------
    // Bật / Tắt Chế độ Game
    // ------------------------------------------------------------------

    private void toggleGameMode() {
        gameModeOn = !gameModeOn;

        applyKeepScreenOn(gameModeOn && swKeepScreen.isChecked());
        applyOrientationLock(gameModeOn && swLockOrientation.isChecked());
        applySustainedPerformance(gameModeOn && swSustainedPerf.isChecked());

        if (gameModeOn && swDnd.isChecked()) {
            applyDnd(true);
        } else if (!gameModeOn) {
            applyDnd(false);
        }

        if (gameModeOn) {
            btnGameMode.setText("⏹ TẮT CHẾ ĐỘ GAME");
            Toast.makeText(this, "Đã bật Chế độ Game", Toast.LENGTH_SHORT).show();
        } else {
            btnGameMode.setText("🚀 BẬT CHẾ ĐỘ GAME");
            Toast.makeText(this, "Đã tắt Chế độ Game", Toast.LENGTH_SHORT).show();
        }
    }

    /** Giữ màn hình luôn sáng trong lúc chơi - API chính thức của Android. */
    private void applyKeepScreenOn(boolean on) {
        if (on) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    /** Khóa hướng màn hình ngang khi chơi game. */
    private void applyOrientationLock(boolean on) {
        if (on) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        }
    }

    /**
     * Sustained Performance Mode: API chính thức từ Android 7.0 (API 24) trở lên.
     * Giúp hiệu năng ổn định lâu dài (tránh giật do máy nóng lên rồi tự hạ xung),
     * đổi lại xung nhịp đỉnh (peak) sẽ thấp hơn một chút so với bình thường.
     */
    private void applySustainedPerformance(boolean on) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            getWindow().setSustainedPerformanceMode(on);
        }
    }

    /**
     * Bật/tắt chế độ Không làm phiền (chặn thông báo) trong lúc chơi.
     * Cần người dùng cấp quyền thủ công trong Settings (Android yêu cầu bắt buộc
     * vì đây là quyền nhạy cảm, app không thể tự bật ngầm).
     */
    private void applyDnd(boolean on) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;

        if (!nm.isNotificationPolicyAccessGranted()) {
            if (on) {
                Toast.makeText(this,
                        "Hãy cấp quyền 'Không làm phiền' cho app rồi bật lại Chế độ Game",
                        Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            }
            return;
        }

        if (on) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
        } else {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
        }
    }

    // ------------------------------------------------------------------
    // Vivo (Funtouch OS) - mở đúng màn hình cấp quyền "Tự khởi động".
    // Android không có API chính thức cho việc này; đây là các màn hình
    // nội bộ mà chính Vivo public trong Funtouch OS 9. Nếu máy Vivo đổi
    // cấu trúc ở bản Funtouch khác, sẽ tự rơi xuống phương án dự phòng
    // là mở thẳng trang "Chi tiết ứng dụng" trong Cài đặt hệ thống.
    // ------------------------------------------------------------------

    private void openVivoAutostartSettings() {
        String[][] candidates = {
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity"},
                {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"},
                {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"},
        };

        for (String[] c : candidates) {
            try {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(c[0], c[1]));
                startActivity(intent);
                Toast.makeText(this,
                        "Hãy tìm 'Gaming Booster' trong danh sách và bật Tự khởi động",
                        Toast.LENGTH_LONG).show();
                return;
            } catch (ActivityNotFoundException | SecurityException ignored) {
                // Thử phương án tiếp theo
            }
        }

        // Dự phòng: mở trang chi tiết app trong Cài đặt hệ thống Android
        // (luôn hoạt động trên mọi máy, kể cả không phải Vivo).
        try {
            Intent fallback = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            fallback.setData(Uri.fromParts("package", getPackageName(), null));
            startActivity(fallback);
            Toast.makeText(this,
                    "Không tìm thấy màn hình riêng của Vivo. Hãy vào Pin > Quản lý nền và bật Tự khởi động thủ công",
                    Toast.LENGTH_LONG).show();
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Không thể mở Cài đặt trên thiết bị này", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------
    // Thông số thiết bị (đọc thật từ hệ thống, không giả lập)
    // ------------------------------------------------------------------

    private void updateRamInfo() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        if (am == null) return;

        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);

        long availMb = mi.availMem / (1024 * 1024);
        long totalMb = mi.totalMem / (1024 * 1024);
        int usedPercent = totalMb > 0 ? (int) (100 - (availMb * 100 / totalMb)) : 0;

        tvRam.setText(String.format("RAM khả dụng: %d MB / %d MB  (đang dùng %d%%)",
                availMb, totalMb, usedPercent));
    }

    private void updateBatteryInfo() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent battery = registerReceiver(null, filter);
        if (battery == null) return;

        int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        int pct = (scale > 0) ? (int) (level * 100f / scale) : -1;

        int tempTenths = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
        float tempC = tempTenths / 10f;

        boolean charging = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                == BatteryManager.BATTERY_STATUS_CHARGING;

        tvBattery.setText(String.format("Pin: %d%%  •  Nhiệt độ: %.1f°C%s",
                pct, tempC, charging ? "  •  Đang sạc" : ""));
    }

    // ------------------------------------------------------------------
    // Dọn bộ nhớ đệm CỦA CHÍNH APP NÀY (không thể và không nên đụng vào
    // app khác - Android chặn việc này từ Android 5.0 vì lý do bảo mật).
    // ------------------------------------------------------------------

    private void clearAppCache() {
        boolean success = deleteDirContents(getCacheDir());
        System.gc();
        Toast.makeText(this,
                success ? "Đã dọn bộ nhớ đệm của app này" : "Bộ nhớ đệm đã trống",
                Toast.LENGTH_SHORT).show();
    }

    private boolean deleteDirContents(File dir) {
        if (dir == null || !dir.isDirectory()) return false;
        String[] children = dir.list();
        if (children == null) return false;
        boolean any = false;
        for (String child : children) {
            File f = new File(dir, child);
            if (f.isDirectory()) {
                deleteDirContents(f);
            }
            if (f.delete()) any = true;
        }
        return any;
    }
}
