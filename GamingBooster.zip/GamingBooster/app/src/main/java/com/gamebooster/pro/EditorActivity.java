package com.gamebooster.pro;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.*;

public class EditorActivity extends AppCompatActivity {
    private EditText etName, etContent;
    private String filePath;
    private boolean isNew;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);
        etName = findViewById(R.id.etFileName);
        etContent = findViewById(R.id.etContent);

        isNew = getIntent().getBooleanExtra("new_file", false);
        filePath = getIntent().getStringExtra("file_path");

        if (isNew) {
            etName.setText("file_" + System.currentTimeMillis() + ".txt");
        } else if (filePath != null) {
            File f = new File(filePath);
            etName.setText(f.getName());
            try {
                FileInputStream in = new FileInputStream(f);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                etContent.setText(out.toString("UTF-8"));
            } catch (Exception e) {
                Toast.makeText(this, "Không đọc được file.", Toast.LENGTH_LONG).show();
            }
        }

        findViewById(R.id.btnEditorBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnSave).setOnClickListener(v -> saveFile());
    }

    private void saveFile() {
        String name = etName.getText().toString().trim();
        if (name.isEmpty()) name = "untitled.txt";
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!name.contains(".")) name += ".txt";

        try {
            File target;
            if (filePath != null && !isNew) target = new File(filePath);
            else target = new File(getFilesDir(), name);

            FileOutputStream out = new FileOutputStream(target);
            out.write(etContent.getText().toString().getBytes("UTF-8"));
            out.close();
            filePath = target.getAbsolutePath();
            isNew = false;
            etName.setText(target.getName());
            Toast.makeText(this, "Đã lưu: " + target.getName(), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Lưu file thất bại: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
